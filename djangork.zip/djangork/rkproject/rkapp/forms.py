from django import forms
from rkapp.models import Employee
class StudentForm(forms.Form):
	firstname =forms.CharField(label='Enter first name',max_length=50)
	lastname =forms.CharField(label='Enter last name',max_length=10)
	lastname =forms.EmailField(label="Enter Email")
	file=froms.FileField()
	