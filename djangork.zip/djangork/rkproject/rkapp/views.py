from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render
from django.template import loader
from django.http  import HttpResponse

from rkapp.functions.functions import handle_uploaded_file
from rkapp.forms import StudentForm




    
def register(request):
    template=loader.get_template('register.html')
    return HttpResponse(template.render())
    
@csrf_exempt   
def register2(request):
    if request.method =='POST':
        template=loader.get_template('print.html')
        
        username=request.POST['username']
        password=request.POST['password']
        address=request.POST['address']
        gender=request.POST['mm']
        
        return render(request,'print.html',{'username':username,'password':password,'address':address,'gender':gender})
        
        
def index(request):
    if request.method=='POST':
        student=StudentForm(request.POST,request.FILES)
        if student.is_valid():
            handle_uploaded_file(request.FILES['file'])
            return HttpRresponse('File uploaded successfuly')
    else:
        student=StudentForm()
        return render(request,"index.html",{'form':student})
        
 

# Create your views here.




