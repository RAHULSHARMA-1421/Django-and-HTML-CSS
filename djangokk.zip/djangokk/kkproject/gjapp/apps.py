from django.apps import AppConfig


class GjappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gjapp'
