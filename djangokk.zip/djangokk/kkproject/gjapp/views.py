from django.shortcuts import render
from django.template import RequestContext
from __future__import unicode_literals
from django.http import HttpResponse
import mysql.connector

# Create your views here.
def index(request):
    cnx=mysql.connector.connect(user="root", password="", host="localhost", database='location')
    cursor=cnx.cursor()
    query="select name,id from countries"
    cursor.execute(query)
    country=cursor.fetchall()
    context-{"country":country}
    cnx.close()
    return render(request,'index.html',context)
    