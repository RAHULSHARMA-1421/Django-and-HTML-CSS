from django.shortcuts import render

# Create your views here.
from django.template import loader

from django.http import HttpResponse
def hello(request):
    return HttpResponse("<h2>Hello, welcome to django!</h2>")
    
def mytemp(request):
    template=loader.get_template('index.html')
    name={
    'student':'rahul'
    }
    return HttpResponse(template.render(name))
    
def mypage(request):
    template=loader.get_template('mytemp.html')
  
    return HttpResponse(template.render())
    
def login(request):
    template=loader.get_template('login.html')
    
    return HttpResponse(template.render())

def about(request):
    template=loader.get_template('about.html')
    
    return HttpResponse(template.render())

def signup(request):
    template=loader.get_template('register.html')
    
    return HttpResponse(template.render())

    
    
